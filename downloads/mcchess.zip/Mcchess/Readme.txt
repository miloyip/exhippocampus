Milo's Chinese Chess
OpenGL Edition
Version 1.00

License: Freeware

Copyright(c) 1998 Yip King Fung(Milo)
All rights reserved.

Web site: http://www.cnblogs.com/miloyip/  http://miloyip.seezone.net
Email: miloyip@gmail.com


Read Me



Table of contents
=================

Part A. General 

	A1. Information
	A2. System Requirement
	A3. List of Files
	A4. Compilation
	A5. Execution

Part B. Implementation

	B1. Rules Implementation
	B2. AI Implementation
	B3. User Interface Implementation
	B4. Features
 

Part C. Notice

	C1. Speed
	C2. Trouble-shooting

Part D. 


--------------------------------------------------------------------------
Part A. General



A1. Information
===============

       Author: Yip King Fung (Milo)
    Cirrculum: BCogSci(II)
University No: 97129302
       E-mail: kfyip@csis.hku.hk



A2. System Requirement
======================

Execution platform:

    Minium requirement:

	- Pentium 100 or above
	- Software OpenGL implementation
	- 32MB RAM
	- Microsoft Window 95/98/NT

    Recommened:

	- Pentium II 200
	- OpenGL supported display card (highly recommened)
	- 64MB RAM
	- Microsoft Window 95/98/NT

Compilation platform:

    Requirement:

	* Visual C++ 5.0 or 6.0



A3. List of Files 
=================

Mcchess100.zip		Runnable archive
Mcchess100_src.zip	Main module source code archive
MiloGL04.zip		MiloGL library source code archive
glutdlls.zip		GLUT 3.6 library


Mcchess100.zip

	Mcchess.exe		Main executable
	Mcchess.cfg		Configuration file
	Book.dat		Book move database
	Readme.txt		This file
	UserGuide.txt		Online help
	Glut32.dll		GLUT32 dynamic-link library
	gfx\*.TGA		Texture bitmaps in Targa format


Mcchess100_src.zip

	Mcchess.dsp		Visual C++ project 
	Mcchess.dsw		Visual C++ workspace 
	Mcchess.mak		Makefile
	c.bat			Build release version batch file

	chs\chs.dsp		Visual C++ project for chs
	chs\chs.cpp		Chess game file convertor source code
	chs\chs.mak		Makefile for chs
	chs\StdAfx.cpp		
	chs\StdAfx.h
	chs\*.chs		Chess open-game files

	Font\font.dsp		Visual C++ project for font
	Font\font.cpp		256 color image to bitmap font converter
	Font\font.mak		makefile for font
	Font\font.h		Output font file
	Font\font1.tga		Input Targa image

	GLinterface\BasicButton.cpp
	GLinterface\BasicButton.h
	GLinterface\BoardCamera.cpp
	GLinterface\BoardCamera.h
	GLinterface\BoardObj.cpp
	GLinterface\BoardObj.h
	GLinterface\Button.cpp
	GLinterface\Button.h
	GLinterface\Camera.cpp
	GLinterface\Camera.h
	GLinterface\Config.cpp
	GLinterface\Config.h
	GLinterface\GameInfo.cpp
	GLinterface\GameInfo.h
	GLinterface\MainMenu.cpp
	GLinterface\MainMenu.h
	GLinterface\McchessGL.cpp
	GLinterface\McchessGL.h
	GLinterface\McchessGLConfig.cpp
	GLinterface\McchessGLConfig.h
	GLinterface\Menu.cpp
	GLinterface\Menu.h
	GLinterface\MovePieceAct.cpp
	GLinterface\MovePieceAct.h
	GLinterface\Obj3D.cpp
	GLinterface\Obj3D.h
	GLinterface\Opening.cpp
	GLinterface\Opening.h
	GLinterface\PieceObj.cpp
	GLinterface\PieceObj.h
	GLinterface\PosObj.cpp
	GLinterface\PosObj.h
	GLinterface\Status.cpp
	GLinterface\Status.h
	GLinterface\TurnObj.cpp
	GLinterface\TurnObj.h

	Kernal\Board.cpp
	Kernal\Board.h
	Kernal\BoardTable.cpp
	Kernal\BoardTable.h
	Kernal\Book.cpp
	Kernal\Book.h
	Kernal\CannonPiece.cpp
	Kernal\CannonPiece.h
	Kernal\ChessInterface.cpp
	Kernal\ChessInterface.h
	Kernal\ComPlayer.cpp
	Kernal\ComPlayer.h
	Kernal\defs.h
	Kernal\Game.cpp
	Kernal\Game.h
	Kernal\GuardPiece.cpp
	Kernal\GuardPiece.h
	Kernal\HumanPlayer.cpp
	Kernal\HumanPlayer.h
	Kernal\KingPiece.cpp
	Kernal\KingPiece.h
	Kernal\KnightPiece.cpp
	Kernal\KnightPiece.h
	Kernal\MinisterPiece.cpp
	Kernal\MinisterPiece.h
	Kernal\PawnPiece.cpp
	Kernal\PawnPiece.h
	Kernal\Piece.cpp
	Kernal\Piece.h
	Kernal\Player.cpp
	Kernal\Player.h
	Kernal\RookPiece.cpp
	Kernal\RookPiece.h
	Kernal\Score.h


MiloGL04.zip
	
	MiloGL.dsp		Visual C++ project
	MiloGL.dsw		Visual C++ workspace
	MiloGL.mak		Makefile for MiloGL
	MiloGLApp.cpp
	MiloGLApp.h
	MiloGLImageFile.cpp
	MiloGLImageFile.h
	MiloGLImageFileTGA.cpp
	MiloGLImageFileTGA.h
	MiloGLTask.cpp
	MiloGLTask.h
	MiloGLTexture.cpp
	MiloGLTexture.h
	MiloGLTextureL.cpp
	MiloGLTextureL.h
	MiloGLTextureS.cpp
	MiloGLTextureS.h
	DisplayMode.cpp
	DisplayMode.h
	StdAfx.cpp
	StdAfx.h


glutdlls.zip

	glut.dll		16bit Dynamic-link library
	glut.h			Header for GLUT
	glut.lib		16bit Static link library
	glut32.dll		32bit Static link library
	glut32.lib		32bit Dynamic-link library
	README.win		Readme



A4. Compilation
===============

    The following steps should be used to build Mcchess.

1. Create a <rootpath>, say <rootpath> = "C:\Milo"

2. Extract Mcchess100.zip     to <rootpath>\Mcchess
   Extract Mcchess100_src.zip to <rootpath>\Mcchess
   Extract MiloGL04.zip	      to <rootpath>\MiloGL

3. Extract glut32.lib         to .../DevStudio/vc/lib
   Extract glut.h             to .../DevStudio/vc/h/gl

4. Change directory to <rootpath>\Mcchess
   run "c.bat" to make release version by makefile

5. Copy <rootpath>\Mcchess\Release\Mcchess.exe to
        <rootpath>\Mcchess


Note: Visual C++ contains a vcvars32.bat which setup all necessary 
      environment variables for compilation


A5. Execution
=============

    Mcchess100.zip is a standalone archive that can be run directly by 
excuting Mcchess.exe.

    With compilation process, the program can be run by the newly linked EXE
in <rootpath>\Mcchess.




--------------------------------------------------------------------------
Part B. Implementation


B1. Rules Implementation
========================

    Mcchess implemented most of playing rules including: 

- Legal moves of each type of pieces

- Some moves are invalid because either
    (1) the move side will be in checkmate after that move; or
    (2) both kings will see each other after that move.

- Side with no possible move is loser

- One side cannot loop move its piece 3 times

    However, Mcchess hasn't implemented the rule of draw in Chinese Chess.
Since that draw in Chinese Chess is very difficult to be determinate. And
there are a lot of rules and cases for determination.



B2. AI Implementation
=====================

B2.1 Searching

    Like most of Chinese Chess program, Mcchess uses game tree searching to
find best move in a certain search depth.

    Mcchess has implemented:

- Minimax search with alpha-beta pruning in Negamax form
- Quiescence search
- Iterative deepening with ordering estimation
- Principle Variation
- Depth Variation


  
B2.1.1 Minimax search

    The implementation of minimax search in Mcchess is like:

	AlphaBeta(alpha, beta, depth) {
	    if (depth == 0)
		return Quiescence(alpha, beta);

	    succ = generate all move from current board
	    
	    // sort succ by estimate function

	    for each node n in succ {
		makeMove(n);
		x = -AlphaBeta(alpha, beta, depth - 1);
		takeBack();

		if (x > alpha) {
		    if (x >= beta)
			return beta;
		    alpha = x;
		    // update principle variation here
		}
	    }

	    if (no legal move)
		return -10000 + ply;

	    return alpha;	
	}


    By using negamax fashion, the checking of alpha and beta cut-off are
more simple and efficient. It can automatically alternate maximizing layers
and minimizing layers by changing the sign of return value and pass swapped
alpha beta window.



B2.1.2 Quiescence search

    Sometimes, in the depth = 0 (horizon), there may still have captures and
checkmate. If the search just stop at depth = 0, it may cause lose of pieces
or even lose of game. So that Mcchess uses quiescence search at depth = 0, 
until the situation is stable.

    Mcchess treat the configuration as stable whenever there are no captures
or checkmate. Besides, in quiescence search, the width of tree limit is limited
to capture moves. That is, only nodes that can capture other side is generated.
And there is no depth limitation.



B2.1.3 Iterative deepening

    There are two advantages for iterative deepening search. One is that the
program can output best move with a time limit. Another is that the previous
iteration results can be used to estimate the current iteration. By ordering
the generated nodes by estimate function, the alpha-beta window can be reduced
sooner.

    Due to lack of time for implementation, Mcchess has just take advantage
of the latter one, ordering estimation.

    Mcchess uses a 9x10x9x10 table to record the transposition score,
the score that a piece from one position to another position. If a move can
capture piece, then the estimate function will use MVV/LVA
(Most Valuable Victim/Least Valuable Attacker), otherwise it use the
transposition score.



B2.1.4 Principle Variation

    In both AlphaBeta() and Quiescene() procedures, if there is a cut-off, 
if will update principle variation table. In the next iteration, while the 
search is still following the principle variation, then if any generated moves
is as same as in the principle variation table, then it will be ordered first.



B2.1.5 Depth Variation

    When the game is approaching to be an end-game, the number of possible
moves will be decreased. Then the number of nodes generated will also be
decreased exponentially. In such cases, Mcchess will increase the maximum
depth.

    Also, it is neccessary to increase the depth because in end-game, pieces
need more successive moves in order to capture other side or make other side
in checkmate. Increase of depth let pieces can look forward for more moves
to do so.



B2.2 Static Evaluation

    There are 3 parts of static evaluation function in Mcchess. They are
static scores of each piece type, stand-alone position score of each piece,
and global anlysis which involves inter-relationship among pieces.

    The evaluation function will call EvalSide(curPlayer) - EvalSide(opponent),
in order to find the score of current player. If the score returns positive,
that means the current board configuration is beneficial to current player.



B2.2.1 Static Score of Piece Type

    Each piece type will assign a static score as follows.

	Type	    Score
	-----------------
	King	    80
	Guard	    6
	Minister    6
	Knight	    13
	Rook	    52
	Cannon	    22
	Pawn	    2

	Score Coefficient = 10

    The evaluation function will multiply a static score coefficient to
the sum of static scores of alive pieces.



B2.2.2 Stand-alone position score

    Currently, Mcchess will assign only one goal for pieces to move to,
the king of another side. Rooks, knights, cannons and pawns that getting
closer to the goal will gain marks.

    Besides, since the movement of knight is complicated, there is a score 
table for knights to give a position score.



B2.2.3 Global analysis

    This is the most complicated evaluation. Generally this evaluation
is separated into 3 groups, opening, mid-game and end-game.
    
    For each group, there are a lot of rules to determine the score.
The followings are some examples in opening.

	Rule			Score
	----------------------------------------
	rooks started lately	deduct @13 marks
	king moves randomly	deduct 20 marks
	rook behind knight	deduct @8 marks
	cannon behind knight	gain @8 marks
	paths of knight blocked deduct @4 marks



B2.3 Book moves

    Mcchess is currently contains about 2000 book moves in opening. When it
is computer's turn, it will first try to find out if the current board 
configuration exists in the book move database. If it exists, it uses that
move immediately.

    For more than one move in a single board configuration, it will choose 
one of the move randomly.

    Mcchess uses hash table to implement the book move database, thus the
searching time is only O(1).



B3. User Interface Implementation
================================= 

    This version of Mcchess is ported to OpenGL in Microsoft Windows.
Visual objects, including pieces, board, and even some buttons are 3D
objects. An immediate advantage is realistic graphics and flexible to
change view. And the trade-off is that the machine requires more
processing time if there is no hardware supported OpenGL implementation.

    As in lack of hardware supported OpenGL, some machines may have 
unacceptable rendering speed. Thus Mcchess have implemented some 
lower graphics details as options.

    The Mcchess window includes 6 components: the board, turn indicator,
menu system, button group, game info and status. All of them have special
effects whenever user is interacting with them.



B4. Features
============

Artificial Intelligence related:

- Minimax search with alpha-beta pruning in Negamax form
- Quiescence search
- Iterative deepening with ordering estimation
- Principle Variation
- Depth Variation
- Book move database in hash table
- Different levels of difficulties
- Either Player vs Player, Player vs Computer or Computer vs Computer
    Can be changed on the fly

User Interface related:

- Realistic OpenGL rendering scene
- Possible moves display
- Game info with history moves display
- Back/Forward buttons
- Change of camera view
- Open/Save game
- Multiple options for different level of graphics detail
- Full screen option
- Online user guide




--------------------------------------------------------------------------
Part C. Notice


C1. Speed
=========

    For machines without hardware OpenGL support, the speed of the program
may be not acceptable. To optimize the speed of displaying. User may try to
turn off all or partial following options:

	Display -> Full screen
	Display -> Board texture
	Display -> Mirror effect
	Display -> Slide piece
	Display -> Game Info

In opposite, turn on all the above options can maximize the graphics detail
of this program.

    If the computer use too much time on considering a move, you may
decrease the level of difficulties. Yet the ability of computer will also 
be reduced.
	


C2. Trouble-shooting
====================

Q: Why there are one vertical black line and one horizontal black line on the
   board?
A: You can try to turn on Display -> Advanced Settings -> Texture Border

Q: Why the board texture displays as a mess?
A: You may try to turn off Display -> Advanced Settings -> Texture Border
