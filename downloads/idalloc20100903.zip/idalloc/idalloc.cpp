﻿#include "stdafx.h"
#include <cassert>
#include <algorithm>
#include <functional>
#include <intrin.h>
#include <iostream>
#include <iomanip>

using namespace std;

#define M			256		// ID的數目，且所有ID在[0, M)的區間內

#define TEST_COUNT	10000

#ifdef NDEBUG
#define TEST_REPEATCOUNT	100
#else
#define TEST_REPEATCOUNT	1
#endif

typedef unsigned char byte;
typedef unsigned long dword;

////////////////////////////////////////////////////////////////////////////////
// 純函數形式API

typedef byte (*idalloc_func)(byte*, size_t);

// 檢測ids裡是否含id (C++ 版本)
inline bool contain(byte* ids, size_t n, byte id) {
	assert(ids != NULL);

	return find(ids, ids + n, id) != ids + n;
}

//  檢測ids裡是否含id (C 版本)
//inline bool contain(byte* ids, size_t n, byte id) {
//	assert(ids != NULL);
//
//	for (size_t i = 0; i < n; i++)
//		if (ids[i] == id)
//			return true;
//	return false;
//}

// 測試平均情況
void test_average(idalloc_func idalloc) {
	assert(idalloc != NULL);

	byte ids[M];

	for (size_t i = 0 ; i < M; i++)
		ids[i] = (byte)i;

	srand(0);	// 使每次測試的偽隨機數相同

	size_t n = 0;
	for (int test = 0; test < TEST_COUNT; test++) {
		random_shuffle(ids, ids + M);	// 把整個數組洗牌
		
		for (int repeat = 0; repeat < TEST_REPEATCOUNT; repeat++) {
			byte id = idalloc(ids, n);
			(void)id;
			assert(!contain(ids, n, id));

			// 測試是否最小的id
			for (size_t i = 0; i < id; i++)
				assert(contain(ids, n, (byte)i));
		}

		n = (n + 1) % M;
	}
}

// 測試最壞情況 (ids為無序的[0, M - 2], 結果必然是id = M - 1)
void test_worst(idalloc_func idalloc) {
	assert(idalloc != NULL);

	const size_t n = M - 1;
	byte ids[n];

	srand(0);	// 使每次測試的偽隨機數相同

	for (size_t i = 0 ; i < n; i++)
		ids[i] = (byte)i;

	for (int test = 0; test < TEST_COUNT; test++) {
		random_shuffle(ids, ids + n);

		for (int repeat = 0; repeat < TEST_REPEATCOUNT; repeat++) {
			byte id = idalloc(ids, n);
			(void)id;
			assert(id == M - 1);
		}
	}
}

// 綫性查找 (總是傳回最小id)
// 時間複雜度: O(n^2)
// 臨時內存大小: 0 字節
// 注: 因為n < M，無論ids內的值為何(甚至有重複元素)，必然可找到一個id，所以id的for不用邊界檢查。
byte linear_search(byte* ids, size_t n) {
	assert(ids != NULL);
	assert(n < M);

	// 逐個id檢查是否存在於[ids, ids + n)
	for (byte id = 0; ; id++) 
		if (!contain(ids, n, id))
			return id;
}

// 數ids內有多少個id在[min, max)的區間內
inline size_t count_interval(byte* ids, size_t n, size_t min, size_t max) {
	size_t count = 0;

	for (size_t i = 0; i < n; i++)
		if (ids[i] >= min && ids[i] < max)
			count++;

	return count;
}

// 二分查找 (總是傳回最小id)
// 時間複雜度: O(n lg n)
// 臨時內存大小: 0 字節
byte binary_search(byte* ids, size_t n) {
	assert(ids != NULL);
	assert(n < M);

	size_t l = 0, r = M;

	for(;;) {
		size_t c = (l + r) / 2; // 把id範圍從[l, r)分割為[l, c), [c, r)兩個區間
		size_t count;

		// 以下的條件測試次序保証了傳回最小id
		if ((count = count_interval(ids, n, l, c)) < c - l) {
			if (count == 0)
				return (byte)l;
			r = c;
		}
		else if ((count = count_interval(ids, n, c, r)) < r - c) {
			if (count == 0)
				return (byte)c;
			l = c;
		}
		else
			assert(false); // 因為n < M，不可能找不到任何id
	}
}

// 排序 (總是傳回最小id)
// 時間複雜度: O(n lg n)
// 臨時內存大小: M 字節 (如果可改變ids則是0)
byte sort_stl(byte* ids, size_t n) {
	assert(ids != NULL);
	assert(n < M);

	byte buffer[M];
	memcpy(buffer, ids, n);

	sort(buffer, buffer + n); // 平均 O(n lg n)

	for (size_t i = 0; i < n; i++)
		if (buffer[i] != i)
			return (byte)i;

	return (byte)n;
}

// 堆 (總是傳回最小id)
// 時間複雜度: O(n lg n)
// 臨時內存大小: M 字節 (如果可改變ids則是0)
byte heap_stl(byte* ids, size_t n) {
	assert(ids != NULL);
	assert(n < M);

	byte buffer[M];
	memcpy(buffer, ids, n);

	byte* end = buffer + n;
	make_heap(buffer, end, greater<byte>()); // O(n)

	for (byte id = 0; buffer != end; id++, end--) {
		if (buffer[0] != id)
			return id;
		pop_heap(buffer, end, greater<byte>()); // O(lg n)
	}

	return (byte)n;
}

// 剖分 (總是傳回最小id)
// 時間複雜度: O(n)
// 臨時內存大小: M 字節 (如果可改變ids則是0)
byte partition_stl(byte* ids, size_t n) {
	assert(ids != NULL);
	assert(n < M);

	byte buffer[M];
	memcpy(buffer, ids, n);

	byte *first = buffer, *last = buffer + n;
	size_t l = 0, r = M;

	for (;;) {
		size_t c = (l + r) / 2;
		byte* middle = partition(first, last, bind2nd(less<byte>(), c)); // O(n)
		// 後置條件: [first, middle)內元素 < c 及 [middle, last)內元素 >= c

		// 以下的條件測試次序保証了傳回最小id
		if (first == middle)
			return (byte)l;
		else if ((size_t)distance(first, middle) < c - l) {
			last = middle;
			r = c;
		}
		else if (middle == last)
			return (byte)c;
		else if ((size_t)distance(middle, last) < r - c) {
			first = middle;
			l = c;
		}
		else
			assert(false);
	}
}

// 布爾集合 (總是傳回最小id)
// 時間複雜度: O(n)
// 臨時內存大小: M 字節
byte boolset(byte* ids, size_t n) {
	assert(ids != NULL);
	assert(n < M);

	bool id_used[M] = { false };

	// 填充 id_used
	for (size_t i = 0; i < n; i++) {
		assert(!id_used[ids[i]]); // 此處斷言失敗代表ids有重複元素
		id_used[ids[i]] = true;
	}

	// 掃描id_used去找出最小未用id
	for (size_t i = 0; i < M; i++)
		if (!id_used[i])
			return (byte)i;

	assert(false);
	return 0;
}

// 位集合 (總是傳回最小id)
// 時間複雜度: O(n)
// 臨時內存大小: floor((M + 31) / 32) * 4 字節
byte bitset_standard(byte* ids, size_t n) {
	assert(ids != NULL);
	assert(n < M);

	const size_t dword_count = (M + 31) / 32;
	dword id_unused_bits[dword_count];

	// 開始時設全部id為未用(即設位為1)
	memset(id_unused_bits, ~0, sizeof(id_unused_bits));

	// 填充id_unused_bits (ids內的位清為0)
	for (size_t i = 0; i < n; i++) {
		size_t index = ids[i] / 32;
		dword bitIndex = ids[i] % 32;
		assert(id_unused_bits[index] & (1 << bitIndex));
		id_unused_bits[index] ^= (1 << bitIndex);
	}

	// 掃描id_unused_bits，找出最小未用id
	for (size_t index = 0; index < dword_count; index++) {
		if (dword bits = id_unused_bits[index]) {
			for (dword bitIndex = 0; bitIndex < 32; bitIndex++)
				if (bits & (1 << bitIndex)) {
					dword id = index * 32 + bitIndex;
					assert(id < M);
					return (byte)id;
				}
		}
	}		

	assert(false);
	return 0;
}

// 位集合(使用內部函數(intrinsic))
byte bitset_intrinsic(byte* ids, size_t n) {
	assert(ids != NULL);
	assert(n < M);

	const size_t dword_count = (M + 31) / 32;
	dword id_unused_bits[dword_count];

	// 開始時設全部id為未用(即設位為1)
	memset(id_unused_bits, ~0, sizeof(id_unused_bits));

	// 填充id_unused_bits (ids內的位清為0)
	for (size_t i = 0; i < n; i++) {
		size_t index = ids[i] / 32;
		dword bitIndex = ids[i] % 32;
		assert(id_unused_bits[index] & (1 << bitIndex));
		id_unused_bits[index] ^= (1 << bitIndex);
	}

	// 掃描id_unused_bits，找出最小未用id
	for (size_t index = 0; index < dword_count; index++) {
		dword bitIndex;
		if (_BitScanForward(&bitIndex, id_unused_bits[index])) {
			dword id = index * 32 + bitIndex;
			assert(id < M);
			return (byte)id;
		}
	}

	assert(false);
	return 0;
}

byte dummy(byte*, size_t) {
	return 0;
}

////////////////////////////////////////////////////////////////////////////////
// 含狀態形式API

template <class T>
void test_manager() {
	T manager;
	bool id_allocated[M] = { false };
	byte allocated_ids[M]; // allocated_ids[0]至allocated_ids[id_used_count - 1]儲存無序的已分配id
	size_t allocated_id_count = 0;

	srand(0);	// 使每次測試的偽隨機數相同

	for (int test = 0; test < TEST_COUNT * TEST_REPEATCOUNT; test++) {
		// id集為空時必須進行分配，否則若id集未滿時，有一半概率進行分配
		if (allocated_id_count == 0 || (rand() > RAND_MAX / 2 && allocated_id_count < M))	{
			byte id = manager.alloc();
			assert(!id_allocated[id]);
			id_allocated[id] = true;
			allocated_ids[allocated_id_count++] = id;
		}
		else {
			// 其他情況，隨機抽一個已分配id進行釋放
			assert(allocated_id_count > 0);
			size_t index = rand() % allocated_id_count;
			byte id = allocated_ids[index];
			assert(id_allocated[id]);
			manager.dealloc(id);
			id_allocated[id] = false;
			allocated_ids[index] = allocated_ids[--allocated_id_count]; // 用列表末的id取代已釋放的id
		}
	}
}

// 布爾集合 (總是傳回最小id)
// 分配的時間複雜度: O(n)
// 釋放的時間複雜度: O(1)
// 狀態所需內存: M 字節
struct boolset_manager {
	bool id_used[M];

	boolset_manager() {
		for (size_t i = 0; i < M; i++)
			id_used[i] = false;
	}

	byte alloc() {
		for (size_t i = 0; i < M; i++) {
			if (!id_used[i]) {
				id_used[i] = true;
				return (byte)i;
			}
		}

		assert(0);
		return false;
	}

	void dealloc(byte id) {
		assert(id_used[id]);
		id_used[id] = false;
	}
};

// 棧
// 分配的時間複雜度: O(1)
// 釋放的時間複雜度: O(1)
// 狀態所需內存: M + 4 字節 (使用short top會是 M + 2 字節)
struct stack_manager {
	byte ids[M];
	size_t top;

	stack_manager() : top(M) {
		for (size_t i = 0; i < M; i++)
			ids[i] = (byte)i;
	}

	byte alloc() {
		assert(top > 0);
		return ids[--top];	// 彈出
	}

	void dealloc(byte id) {
		assert(top < M);
		ids[top++] = id;	// 壓入
	}
};

// 數組鏈表 (來自qiaojie)
// 分配的時間複雜度: O(1)
// 釋放的時間複雜度: O(1)
// 狀態所需內存: M + 1 字節 (若以freelist形式儲存，則所需額外內存只是1字節)
struct arraylinkedlist_manager {
	byte next[M];
	byte head;

	arraylinkedlist_manager() : head(0) {
		// 填入完整的環
		for(int i = 0; i < M; ++i)
			next[i] = (byte)(i + 1);
	}

	byte alloc() {
		byte id = head;
		head = next[head];

		// next[id]在這裡已經不需要，可以用來放短訊或其他數據，這裡放置0作為測試。實際上這步是可有可無的。
		next[id] = 0;

		return id;
	}

	void dealloc(byte id) {
		next[id] = head;
		head = id;
	}
};

// 用於數組鏈表的freelist的結構例子
union sms {
	byte next;
	char message[160];
};

struct dummy_manager {
	dummy_manager() {}
	byte alloc() { return 0; }
	void dealloc(byte) {}
};

////////////////////////////////////////////////////////////////////////////////

#define TIME(X) { \
	LARGE_INTEGER start, end, freq; \
	QueryPerformanceCounter(&start); \
	{ X; } \
	QueryPerformanceCounter(&end); \
	QueryPerformanceFrequency(&freq); \
	double duration = (double)(end.QuadPart - start.QuadPart)/(double)freq.QuadPart; \
	cout << setw(10) << fixed << duration << " " << #X << endl; \
}

void main() {
#ifdef NDEBUG
	test_average(dummy); // 熱身
	TIME(test_average(dummy));
#endif

	TIME(test_average(linear_search));
	TIME(test_average(binary_search));
	TIME(test_average(sort_stl));
	TIME(test_average(heap_stl));
	TIME(test_average(partition_stl));
	TIME(test_average(boolset));
	TIME(test_average(bitset_standard));
	TIME(test_average(bitset_intrinsic));

	cout << endl;

#ifdef NDEBUG
	TIME(test_worst(dummy));
#endif

	TIME(test_worst(linear_search));
	TIME(test_worst(binary_search));
	TIME(test_worst(sort_stl));
	TIME(test_worst(heap_stl));
	TIME(test_worst(partition_stl));
	TIME(test_worst(boolset));
	TIME(test_worst(bitset_standard));
	TIME(test_worst(bitset_intrinsic));

	cout << endl;

#ifdef NDEBUG
	TIME(test_manager<dummy_manager>());
#endif

	TIME(test_manager<boolset_manager>());
	TIME(test_manager<stack_manager>());
	TIME(test_manager<arraylinkedlist_manager>());
}
